#pragma once

typedef enum bool {false, true} bool;
