#include "common.h"

int numdiff(const int l[], const int n)
{

}          
