#include "common.h"

int closestmean(const int l[], const int n)
{

}          
