#include "common.h"

bool struses(const char* s1, const char* s2)
{
}
